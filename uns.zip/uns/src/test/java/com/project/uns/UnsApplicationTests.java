package com.project.uns;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UnsApplicationTests {

	@Test
	void contextLoads() {
	}

}
