package com.project.uns.dto;
import lombok.Data;

@Data
public class RegisterDto {
    private Long id;
    private String jmbg;
    private String name;
    private String lastName;
}


